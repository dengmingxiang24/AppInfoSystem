package cn.appsys.service.dev.user;

import cn.appsys.pojo.DevUser;

public interface DevUserService {
	/*
	 * 用户登录
	 */
	DevUser queryCodeAndPwd(String devCode,String devPassword);
}
