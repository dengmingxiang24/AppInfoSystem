package cn.appsys.constant;

public class Constants {
	//用户设置开发者平台登录成功后，将登录用户保存到session中，其中key的值为：
	public static final String DEV_USER_SESSION = "devUserSession";
}
