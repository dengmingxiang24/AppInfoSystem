package cn.appsys.dao.dev.user;

import org.apache.ibatis.annotations.Param;

import cn.appsys.pojo.DevUser;

//开发者平台所对应用户接口
public interface DevUserMapper {
	/*
	 * 用户登录
	 */
	DevUser queryCodeAndPwd(@Param("devCode")String devCode,
			@Param("devPassword")String devPassword);
}
